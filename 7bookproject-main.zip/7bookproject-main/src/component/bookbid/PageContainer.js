import styled from 'styled-components';

const PageContainer = styled.div`
  margin: 0 auto;
  width: 80%;
`;

export default PageContainer;
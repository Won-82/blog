import React from 'react'

export default function FindIdPw() {
  return (
    <div>FindIdPw</div>
  )
}
